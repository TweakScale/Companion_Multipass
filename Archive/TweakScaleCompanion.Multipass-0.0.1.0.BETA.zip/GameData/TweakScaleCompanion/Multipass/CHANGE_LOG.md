# TweakScale Companion :: Multipass :: Change Log

* 2020-0607: 0.0.1.0 (LisiasT) for KSP >= 1.2.2
	+ Initial public release 
