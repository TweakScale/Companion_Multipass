# TweakScale Companion :: Multipass :: Change Log

* 2020-0719: 0.0.1.1 (LisiasT) for KSP >= 1.2.2
	+ Patches revision.
		- Reorganisation
		- Double checking with the lint tool.
	+ Temporarily resurrected that magnificent MJ2 Pod for debugging.
* 2020-0607: 0.0.1.0 (LisiasT) for KSP >= 1.2.2
	+ Initial public release 
