# TweakScale Companion :: Multipass :: Change Log

* 2023-1005: 0.1.0.0 (LisiasT) for KSP >= 1.2.2
	+ Removes Arc Aerospace, moving it to TSCo-Rockets
	+ Updates the Documentation
	+ Implements Issues:
		- [#15](https://github.com/TweakScale/Companion/issues/15) Extend the fix implemented on TweakScaleCompanion_NF#2 to every Companion
* 2020-1101: 0.0.2.0 (LisiasT) for KSP >= 1.2.2
	+ Adding patches for Tarsier Space Techonologies
	+ Some normalisation on the existing patches
* 2020-0719: 0.0.1.1 (LisiasT) for KSP >= 1.2.2
	+ Patches revision.
		- Reorganisation
		- Double checking with the lint tool.
	+ Temporarily resurrected that magnificent MJ2 Pod for debugging.
* 2020-0607: 0.0.1.0 (LisiasT) for KSP >= 1.2.2
	+ Initial public release 
